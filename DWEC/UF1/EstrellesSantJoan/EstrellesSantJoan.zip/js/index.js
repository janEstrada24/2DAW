function mostrarDada(dada, i) {
    let resultats = document.getElementsByTagName('p');
    resultats[i].innerHTML = dada.value;
}

function guardar_localStorage() {
    let numeroEstrelles = document.getElementsByClassName('dades')[0].value;
    let radiEstrella = document.getElementsByClassName('dades')[1].value;
    let distanciaEstrella = document.getElementsByClassName('dades')[2].value;

    localStorage.setItem("numeroEstrelles", numeroEstrelles);
    localStorage.setItem("radiEstrella", radiEstrella);
    localStorage.setItem("distanciaEstrella", distanciaEstrella);
    document.getElementsByClassName("dades")[0].value = parseInt(quantitat);
    document.getElementsByClassName("dades")[1].value = parseInt(radi);
    document.getElementsByClassName("dades")[2].value = parseInt(distancia);

    document.getElementsByTagName('p')[0].innerHTML = parseInt(numeroEstrelles);
    document.getElementsByTagName('p')[1].innerHTML = parseInt(radiEstrella);
    document.getElementsByTagName('p')[2].innerHTML = parseInt(distanciaEstrella);

}

window.onload = function start() {
    let dades = document.getElementsByClassName('dades');
    for (let i = 0; i < dades.length; i++) {
        dades[i].addEventListener('change', () => mostrarDada(dades[i], i));
    }
    guardar_localStorage();

    botoMostrar = document.getElementsByTagName("button")[0];
}