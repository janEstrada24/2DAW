function dibuixarEstrella() {
    let quantitat = parseInt(localStorage.getItem('numeroEstrelles'));
    let radi = parseInt(localStorage.getItem('radiEstrella')) ;
    var requadre = document.getElementById("requadre");
    const angleInici = 0;
    const angleFinal = Math.PI * 2;
    let opacitat = Math.random() * 1;
    for (let i = 0; i < quantitat; i++) {
        let x = Math.floor(Math.random() * requadre.width);
        let y = Math.floor(Math.random() * requadre.height);
        let estrella = requadre.getContext("2d");
        estrella.fillStyle = "#FFFFFF";
        estrella.moveTo(x, y);
        estrella.arc(x, y, radi, angleInici, angleFinal);
        estrella.globalAlpha = opacitat;
        estrella.fill();
        requadre.append(estrella);
    }
}


function retornarPagina() {
    location.href = "../html/index.html";
}
window.onload = function start() {
    const boto = document.getElementsByTagName('button')[0];
    boto.addEventListener("click", retornarPagina);
    
    dibuixarEstrella();

    const radio = document.getElementsByTagName('input')[0];
    radio.value = parseInt(localStorage.getItem('numeroEstrelles'));
}