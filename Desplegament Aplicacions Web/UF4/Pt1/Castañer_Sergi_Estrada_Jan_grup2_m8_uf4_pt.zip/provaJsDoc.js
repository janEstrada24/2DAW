/**
 * 
 * @param {number} nom 
 * @param {number} edat 
 * @param {boolean} esMajorDedat 
 * @returns {Object}
 */
function crearPersona (nom, edat, esMajorDedat) {
    return {
        nom: nom,
        edat: edat,
        esMajorDedat: esMajorDedat
    }
}

/** Your class description */
class Persona {
    /**
     * 
     * @param {number} nom 
     * @param {number} edat 
     * @param {boolean} esMajorDedat 
     */
    constructor (nom, edat, esMajorDedat) {
        this.nom = nom;
        this.edat = edat;
        this.esMajorDedat = esMajorDedat;
    }
}