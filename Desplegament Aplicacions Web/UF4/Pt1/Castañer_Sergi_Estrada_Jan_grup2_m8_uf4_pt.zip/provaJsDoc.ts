/**
 * Description
 * @param {number} amplada
 * @param {number} llargada
 * @param {number} altura
 * @returns {String}
 */
function imprimirCaracteristica(amplada: number, llargada: number, altura: number) {
    let resultat = "";

    resultat = "Característiques: " + amplada + " x " + llargada + " x " + altura + "<br>";
    return resultat;
}
